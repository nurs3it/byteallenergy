__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/a7702373829cfe15.js",
  "static/chunks/turbopack-ca411ac433b91247.js"
])
